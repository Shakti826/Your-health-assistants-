export interface ProductSuggestion {
  name: string;
  description: string;
}

export interface AnalysisResult {
  possibleCauses: string[];
  selfCareTips: string[];
  productSuggestions: ProductSuggestion[];
  warning: string;
}
