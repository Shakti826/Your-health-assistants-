import React from 'react';
import { ChevronDownIcon } from '../constants';

interface AccordionProps {
  title: string;
  icon: React.ReactNode;
  isOpen: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}

const Accordion = ({ title, icon, isOpen, onToggle, children }: AccordionProps) => {
  return (
    <div className="border border-slate-200 rounded-lg overflow-hidden mb-3 bg-white shadow-sm">
      <button
        onClick={onToggle}
        className="w-full flex justify-between items-center p-4 text-left font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 focus:outline-none focus-visible:ring focus-visible:ring-blue-500 focus-visible:ring-opacity-75 transition-colors"
        aria-expanded={isOpen}
      >
        <div className="flex items-center space-x-3">
          <span className="text-blue-600">{icon}</span>
          <span>{title}</span>
        </div>
        <div className={`${isOpen ? 'rotate-180' : ''} transition-transform duration-300`}>
            <ChevronDownIcon />
        </div>
      </button>
      <div
        className={`grid transition-all duration-500 ease-in-out ${
          isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
        }`}
      >
        <div className="overflow-hidden">
          <div className="p-4 text-slate-700">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Accordion;