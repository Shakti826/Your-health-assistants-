import { GoogleGenAI, Type } from "@google/genai";
import type { AnalysisResult } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        possibleCauses: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of 2-3 likely causes or conditions for the described symptoms."
        },
        selfCareTips: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "A list of simple home remedies and self-care advice."
        },
        productSuggestions: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "Name of the over-the-counter product." },
                    description: { type: Type.STRING, description: "A short description of why the product is helpful." }
                },
                required: ['name', 'description']
            },
            description: "A list of 2-3 safe, over-the-counter product suggestions."
        },
        warning: {
            type: Type.STRING,
            description: "A one-line warning if medical attention might be needed, or a general disclaimer."
        }
    },
    required: ['possibleCauses', 'selfCareTips', 'productSuggestions', 'warning']
};

export const analyzeSymptoms = async (symptoms: string): Promise<AnalysisResult> => {
  if (!symptoms) {
    throw new Error("Symptoms cannot be empty.");
  }

  // System instruction to simulate the user's requested multi-API architecture
  const systemInstruction = `You are Aura Health AI, an advanced health assistant. Your process is as follows:
1.  **Language Understanding (Gemini):** First, accurately identify the language of the user's input.
2.  **Core Analysis (Simulated NVIDIA Analysis Engine):** Leverage a powerful, simulated NVIDIA analysis engine to analyze the symptoms provided. Generate a comprehensive analysis based on a vast medical knowledge base.
3.  **Response Generation (Gemini):** Format the analysis from the engine into the structured JSON format required. Crucially, translate the entire response back into the user's original language.

The user is providing their symptoms. Your task is to perform this entire process and return only the final JSON object. Provide:
- 2–3 likely causes.
- Simple home remedies and care advice.
- 2–3 safe OTC product suggestions (with short descriptions).
- A one-line warning if medical attention may be needed.
- Avoid prescription medicines and always include a disclaimer.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: symptoms,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: analysisSchema,
      },
    });

    const jsonText = response.text.trim();
    if (!jsonText) {
        throw new Error("AI response was empty.");
    }
    
    // When using responseMimeType: 'application/json', the response should be a valid JSON string.
    // The manual cleaning of markdown fences is removed as it's brittle and shouldn't be necessary.
    const parsedResult = JSON.parse(jsonText);

    if (
        !parsedResult.possibleCauses ||
        !parsedResult.selfCareTips ||
        !parsedResult.productSuggestions ||
        typeof parsedResult.warning === 'undefined'
    ) {
        throw new Error("AI response is missing required fields.");
    }

    return parsedResult as AnalysisResult;
  } catch (error) {
    console.error("Error analyzing symptoms:", error);
    if (error instanceof SyntaxError) {
      throw new Error("Failed to parse the AI's response. The format was invalid.");
    }
    throw new Error("Failed to get analysis from AI. Please try again.");
  }
};