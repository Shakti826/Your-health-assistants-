import React, { useState, useEffect } from 'react';
import { analyzeSymptoms } from './services/geminiService';
import type { AnalysisResult } from './types';
import Accordion from './components/Accordion';
import { CauseIcon, RemedyIcon, ProductIcon, AnalyzeIcon, NewChatIcon, PrivacyIcon, TermsIcon, ContactIcon } from './constants';

const templates = [
  { name: "Cold & Flu", symptoms: "I have a sore throat, runny nose, cough, and body aches. I've been feeling tired for two days." },
  { name: "Headache", symptoms: "I have a throbbing pain on one side of my head, and I'm sensitive to light and sound." },
  { name: "Stomach Pain", symptoms: "I have a sharp, cramping pain in my lower abdomen, and I feel bloated." },
  { name: "Allergies", symptoms: "My eyes are itchy and watery, I'm sneezing a lot, and my nose is congested." },
  { name: "Back Pain", symptoms: "There's a dull, persistent ache in my lower back that gets worse when I sit for a long time." },
  { name: "Skin Rash", symptoms: "I have a red, itchy rash on my arms with small bumps. It appeared yesterday." },
  { name: "Insomnia", symptoms: "I have trouble falling asleep at night and wake up several times. I feel tired during the day." },
  { name: "Muscle Strain", symptoms: "I felt a sharp pain in my calf while running, and now it's sore and tender to the touch." },
];

const WelcomeScreen = ({ onAccept }: { onAccept: () => void }) => {
    const [openAccordion, setOpenAccordion] = useState<string | null>(null);
    const [isAgreed, setIsAgreed] = useState<boolean>(false);

    const toggleAccordion = (id: string) => {
        setOpenAccordion(openAccordion === id ? null : id);
    };

    return (
        <div className="bg-white p-6 md:p-8 rounded-lg shadow-md animate-fade-in">
            <header className="text-center mb-6">
                <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-500">
                    Welcome to Aura Health AI
                </h1>
                <p className="text-slate-600 mt-2">Your personal AI-powered symptom analyzer.</p>
            </header>
            <div className="text-slate-700 space-y-4 mb-6">
                <p>Before you begin, please review the following information. This application is for informational purposes and is not a substitute for professional medical advice.</p>
            </div>
            
            <div className="space-y-2 mb-6">
                 <Accordion
                    title="Privacy Policy"
                    icon={<PrivacyIcon />}
                    isOpen={openAccordion === 'privacy'}
                    onToggle={() => toggleAccordion('privacy')}
                    children={
                        <div className="text-sm space-y-2">
                            <p>We respect your privacy. The symptoms you provide are sent to the AI for analysis and are not stored or shared with third parties. All analysis is performed anonymously. We do not collect any personal identifiable information.</p>
                        </div>
                    }
                />
                 <Accordion
                    title="Terms & Conditions"
                    icon={<TermsIcon />}
                    isOpen={openAccordion === 'terms'}
                    onToggle={() => toggleAccordion('terms')}
                    children={
                         <div className="text-sm space-y-2">
                           <p>By using Aura Health AI, you agree that this tool is not a medical device and does not provide medical advice. It is intended for informational purposes only. You agree to consult a qualified healthcare professional for any medical concerns or before making any health decisions. The developers are not liable for any actions taken based on the information provided by this app.</p>
                        </div>
                    }
                />
                 <Accordion
                    title="Contact"
                    icon={<ContactIcon />}
                    isOpen={openAccordion === 'contact'}
                    onToggle={() => toggleAccordion('contact')}
                    children={
                        <div className="text-sm">
                           <p>For questions or feedback, please contact us at <a href="mailto:support@aurahealth.ai" className="text-blue-600 hover:underline">support@aurahealth.ai</a>.</p>
                        </div>
                    }
                />
            </div>
            
            <div className="flex items-start space-x-3 mb-6">
                <input
                    id="terms-agree"
                    type="checkbox"
                    checked={isAgreed}
                    onChange={() => setIsAgreed(!isAgreed)}
                    className="mt-1 h-4 w-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                    aria-label="Agree to terms and conditions"
                />
                <label htmlFor="terms-agree" className="text-sm text-slate-600">
                    I understand that this is not a medical device and{" "}
                    <button
                        onClick={() => toggleAccordion('terms')}
                        className="text-blue-600 hover:underline font-semibold"
                    >
                        agree to the terms
                    </button>
                    .
                </label>
            </div>


            <button
                onClick={onAccept}
                disabled={!isAgreed}
                className="w-full bg-blue-600 text-white px-4 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-slate-400 disabled:cursor-not-allowed transition-colors"
            >
                Agree & Continue
            </button>
        </div>
    );
};


const App = () => {
  const [symptoms, setSymptoms] = useState<string>('');
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [openAccordion, setOpenAccordion] = useState<string | null>(null);
  const [hasAcceptedTerms, setHasAcceptedTerms] = useState<boolean>(false);

  useEffect(() => {
    const accepted = sessionStorage.getItem('aura-health-accepted-terms');
    if (accepted === 'true') {
        setHasAcceptedTerms(true);
    }
  }, []);

  const handleAcceptTerms = () => {
    sessionStorage.setItem('aura-health-accepted-terms', 'true');
    setHasAcceptedTerms(true);
  };
  
  const handleAnalyze = async () => {
    if (!symptoms.trim()) {
      setError('Please enter your symptoms before analyzing.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setAnalysis(null);
    setOpenAccordion(null);

    try {
      const result = await analyzeSymptoms(symptoms);
      setAnalysis(result);
      if (result?.possibleCauses?.length) {
        setOpenAccordion('causes');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewChat = () => {
    setSymptoms('');
    setAnalysis(null);
    setError(null);
    setIsLoading(false);
    setOpenAccordion(null);
    document.querySelector('textarea')?.focus();
  };

  const toggleAccordion = (id: string) => {
    setOpenAccordion(openAccordion === id ? null : id);
  };

  if (!hasAcceptedTerms) {
      return (
          <div className="bg-slate-50 min-h-screen font-sans flex items-center justify-center">
              <div className="container mx-auto p-4 max-w-2xl">
                  <WelcomeScreen onAccept={handleAcceptTerms} />
              </div>
          </div>
      );
  }

  return (
    <div className="bg-slate-50 min-h-screen font-sans">
      <div className="container mx-auto p-4 max-w-2xl">
        <header className="text-center my-6 md:my-8">
            <div className="flex justify-center items-center gap-4">
                <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-500">
                    Aura Health AI
                </h1>
            </div>
            <p className="text-slate-600 mt-2">Your personal AI-powered symptom analyzer</p>
        </header>

        <main className="bg-white p-6 rounded-lg shadow-md">
           <h2 className="text-xl font-semibold text-slate-700 mb-4">Describe Your Symptoms</h2>

          <div className="relative mb-4">
            {analysis && (
                 <button
                    onClick={handleNewChat}
                    className="absolute top-3 right-3 z-10 flex items-center gap-1.5 text-sm text-blue-600 hover:text-blue-800 transition-colors p-1"
                    title="Start New Chat"
                    aria-label="Start New Chat"
                 >
                    <NewChatIcon />
                 </button>
            )}
            <textarea
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              placeholder="e.g., 'I have a sore throat, a runny nose, and I've been coughing for two days...'"
              className="w-full h-36 p-4 pr-32 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow resize-none"
              disabled={isLoading}
              onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleAnalyze();
                  }
              }}
            />
            <button
              onClick={handleAnalyze}
              disabled={isLoading || !symptoms.trim()}
              className={`absolute bottom-4 right-4 flex items-center justify-center gap-2 w-28 h-10 text-white px-4 py-2 rounded-lg font-semibold disabled:cursor-not-allowed transition-all duration-300
                ${isLoading 
                  ? 'bg-gradient-to-r from-blue-500 to-cyan-400 animate-pulse-bg' 
                  : 'bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400'
                }`}
            >
              {isLoading ? (
                  <span>Analyzing...</span>
              ) : (
                <>
                  <AnalyzeIcon />
                  <span>Analyze</span>
                </>
              )}
            </button>
          </div>

          <div className="mt-4">
            <p className="text-sm font-semibold text-slate-600 mb-2">Or try an example:</p>
            <div className="flex flex-wrap gap-2">
                {templates.map((template) => (
                    <button
                        key={template.name}
                        onClick={() => setSymptoms(template.symptoms)}
                        className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm hover:bg-slate-200 transition-colors disabled:opacity-50"
                        disabled={isLoading}
                    >
                        {template.name}
                    </button>
                ))}
            </div>
          </div>


          {error && <div className="mt-4 text-red-600 bg-red-100 p-3 rounded-lg animate-fade-in">{error}</div>}
        </main>

        {analysis && (
          <section className="mt-6 animate-fade-in">
            <h3 className="text-2xl font-semibold text-slate-800 mb-4 text-center">Analysis Results</h3>
            
            <Accordion
              title="Possible Causes"
              icon={<CauseIcon />}
              isOpen={openAccordion === 'causes'}
              onToggle={() => toggleAccordion('causes')}
              children={
                <ul className="list-disc list-inside space-y-2">
                  {analysis.possibleCauses.map((cause, index) => <li key={index}>{cause}</li>)}
                </ul>
              }
            />

            <Accordion
              title="Self-Care & Remedies"
              icon={<RemedyIcon />}
              isOpen={openAccordion === 'remedies'}
              onToggle={() => toggleAccordion('remedies')}
              children={
                <ul className="list-disc list-inside space-y-2">
                  {analysis.selfCareTips.map((tip, index) => <li key={index}>{tip}</li>)}
                </ul>
              }
            />

            <Accordion
              title="Product Suggestions"
              icon={<ProductIcon />}
              isOpen={openAccordion === 'products'}
              onToggle={() => toggleAccordion('products')}
              children={
                <ul className="space-y-3">
                  {analysis.productSuggestions.map((product, index) => (
                    <li key={index}>
                      <strong className="font-semibold text-slate-800">{product.name}</strong>: {product.description}
                    </li>
                  ))}
                </ul>
              }
            />

            {analysis.warning && (
              <div className="mt-4 p-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 rounded-r-lg">
                <p><strong className="font-semibold">Important:</strong> {analysis.warning}</p>
              </div>
            )}
          </section>
        )}

        <footer className="text-center text-xs text-slate-500 mt-8 pb-4">
            Disclaimer: Aura Health AI is for informational purposes only and does not constitute medical advice. Always consult with a healthcare professional for diagnosis and treatment.
        </footer>
      </div>
    </div>
  );
};

export default App;